DUT:
Adder.vhd - file which contains the Adder. Gets two vectors, and carry in bit  and returns a vector which is the sum  and a carry bit. 
aux_package.vhd - package that contains declaration of top & FA entities.
Top.vhd - Contains the entity and architecture that detects valid subseries for a given vector and detection code and returns if the last 'm' clock cycles Meet the conditions, as described in the assignment. For more details, refer to the assignment or the PDF



